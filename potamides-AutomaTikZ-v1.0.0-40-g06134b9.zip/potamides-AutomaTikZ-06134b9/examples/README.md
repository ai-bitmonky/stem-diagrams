# Examples
The examples in this directory and subdirectories may be helpful for
understanding how this library works. Each script has a command line interface
and additional information can be found by invoking them with the ``--help``
flag.
