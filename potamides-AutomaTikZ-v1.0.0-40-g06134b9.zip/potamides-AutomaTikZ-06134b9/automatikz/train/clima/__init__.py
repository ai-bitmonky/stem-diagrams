from .train import train, load
from .pretrain import train as pretrain
