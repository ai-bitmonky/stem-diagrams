"""
CapacitorInterpreter - Converts capacitor problem specs into renderable scenes

Handles:
- Parallel-plate capacitors (with/without dielectrics)
- Series/parallel capacitor circuits
- Electric fields and charge distributions
- Battery connections
"""

from typing import Dict, List, Optional
from core.scene.schema_v1 import Scene, SceneObject, Constraint, PrimitiveType, ConstraintType
from core.universal_ai_analyzer import PhysicsDomain


class CapacitorInterpreter:
    """Interprets capacitor problem specifications into visual scenes"""

    def __init__(self):
        self.canvas_width = 1200
        self.canvas_height = 800
        self.center_x = self.canvas_width // 2
        self.center_y = self.canvas_height // 2

    def interpret(self, spec: Dict) -> Scene:
        """Main entry point - converts spec to Scene

        Args:
            spec: Dictionary with keys:
                - objects: List of physical objects (capacitors, dielectrics, etc.)
                - relationships: Connections between objects
                - environment: Physical constants

        Returns:
            Scene with positioned objects and constraints
        """
        print(f"   🔌 CapacitorInterpreter: Processing {len(spec.get('objects', []))} objects")

        scene_objects = []
        constraints = []

        objects = spec.get('objects', [])
        relationships = spec.get('relationships', [])

        # Identify problem type from objects
        has_capacitor = any('capacitor' in str(obj.get('type', '')).lower() for obj in objects)
        has_dielectric = any('dielectric' in str(obj.get('type', '')).lower() for obj in objects)
        has_circuit = any('battery' in str(obj.get('type', '')).lower() or
                         'wire' in str(obj.get('type', '')).lower() for obj in objects)

        if has_circuit:
            # Circuit with multiple capacitors
            scene_objects, constraints = self._create_circuit(objects, relationships)
        elif has_dielectric:
            # Single capacitor with dielectric
            scene_objects, constraints = self._create_capacitor_with_dielectric(objects)
        else:
            # Simple parallel-plate capacitor
            scene_objects, constraints = self._create_simple_capacitor(objects)

        print(f"   ✅ Created {len(scene_objects)} scene objects, {len(constraints)} constraints")

        return Scene(
            metadata={"domain": PhysicsDomain.ELECTROSTATICS.value, "renderer": "capacitor"},
            objects=scene_objects,
            constraints=constraints
        )

    def _create_simple_capacitor(self, objects: List[Dict]) -> tuple:
        """Create a simple parallel-plate capacitor"""
        scene_objects = []
        constraints = []

        # Find capacitor properties
        capacitor = next((obj for obj in objects if 'capacitor' in str(obj.get('type', '')).lower()), None)

        plate_width = 300
        plate_height = 10
        separation = 150

        if capacitor:
            props = capacitor.get('properties', {})
            # Extract separation if available
            if 'separation' in props:
                separation = props['separation'] * 10000  # Convert m to pixels (rough scale)
                separation = min(max(separation, 100), 300)  # Clamp between 100-300px

        # Top plate (positive)
        top_plate = SceneObject(
            id="plate_top",
            type=PrimitiveType.RECTANGLE,
            position={"x": self.center_x - plate_width//2, "y": self.center_y - separation//2 - plate_height},
            properties={"width": plate_width, "height": plate_height, "charge": "+Q"},
            style={"fill": "#ff4444", "stroke": "#d32f2f", "stroke_width": 2}
        )

        # Bottom plate (negative)
        bottom_plate = SceneObject(
            id="plate_bottom",
            type=PrimitiveType.RECTANGLE,
            position={"x": self.center_x - plate_width//2, "y": self.center_y + separation//2},
            properties={"width": plate_width, "height": plate_height, "charge": "-Q"},
            style={"fill": "#4444ff", "stroke": "#1976d2", "stroke_width": 2}
        )

        scene_objects.extend([top_plate, bottom_plate])

        # Add electric field lines (arrows pointing downward)
        num_field_lines = 5
        for i in range(num_field_lines):
            x_offset = (i - num_field_lines//2) * (plate_width // num_field_lines)
            field_line = SceneObject(
                id=f"field_line_{i}",
                type=PrimitiveType.ARROW,
                position={
                    "x1": self.center_x + x_offset,
                    "y1": self.center_y - separation//2 + plate_height + 10,
                    "x2": self.center_x + x_offset,
                    "y2": self.center_y + separation//2 - 10
                },
                properties={"direction": "down"},
                style={"stroke": "#ff6600", "stroke_width": 2, "marker_end": "arrowhead"}
            )
            scene_objects.append(field_line)

        # Add constraints
        constraints.append(Constraint(
            type=ConstraintType.PARALLEL,
            objects=["plate_top", "plate_bottom"]
        ))

        constraints.append(Constraint(
            type=ConstraintType.DISTANCE,
            objects=["plate_top", "plate_bottom"],
            value=separation
        ))

        return scene_objects, constraints

    def _create_capacitor_with_dielectric(self, objects: List[Dict]) -> tuple:
        """Create capacitor with dielectric slab including detailed annotations"""
        # Start with simple capacitor
        scene_objects, constraints = self._create_simple_capacitor(objects)

        # Extract capacitor and dielectric properties
        capacitor = next((obj for obj in objects if 'capacitor' in str(obj.get('type', '')).lower()), None)
        dielectric = next((obj for obj in objects if 'dielectric' in str(obj.get('type', '')).lower()), None)

        cap_props = capacitor.get('properties', {}) if capacitor else {}
        di_props = dielectric.get('properties', {}) if dielectric else {}

        # Extract physical values
        plate_area = cap_props.get('plate_area', cap_props.get('area', ''))
        plate_sep = cap_props.get('plate_separation', cap_props.get('separation', ''))
        voltage = cap_props.get('voltage', cap_props.get('initial_potential_difference', ''))
        thickness = di_props.get('thickness', 0.004) * 10000  # Convert m to pixels
        thickness = min(max(thickness, 40), 100)  # Clamp
        kappa = di_props.get('dielectric_constant', di_props.get('kappa', di_props.get('k', '')))

        if dielectric:
            # Add dielectric slab between plates
            dielectric_obj = SceneObject(
                id="dielectric",
                type=PrimitiveType.RECTANGLE,
                position={
                    "x": self.center_x - 130,
                    "y": self.center_y - thickness//2
                },
                properties={"width": 260, "height": thickness, "kappa": kappa},
                style={
                    "fill": "url(#dielectricPattern)",
                    "fill_opacity": 0.6,
                    "stroke": "#42a5f5",
                    "stroke_width": 2
                }
            )
            scene_objects.insert(2, dielectric_obj)  # Insert after plates, before field lines

        # Add CHARGE LABELS to plates
        for obj in scene_objects:
            if obj.id == 'plate_top':
                obj.properties['label'] = '+Q'
            elif obj.id == 'plate_bottom':
                obj.properties['label'] = '-Q'

        # Add DISTANCE ARROW showing plate separation
        arrow_x = self.center_x - 200
        distance_arrow = SceneObject(
            id="separation_arrow",
            type=PrimitiveType.ARROW,
            position={
                "x1": arrow_x, "y1": self.center_y - 75,
                "x2": arrow_x, "y2": self.center_y + 75,
                "double_headed": True
            },
            properties={"bidirectional": True},
            style={"stroke": "#555", "stroke_width": 2, "marker_start": "arrowhead", "marker_end": "arrowhead"}
        )
        scene_objects.append(distance_arrow)

        # Add separation distance label
        if plate_sep:
            sep_label = SceneObject(
                id="separation_label",
                type=PrimitiveType.TEXT,
                position={"x": arrow_x - 40, "y": self.center_y},
                properties={"text": f"d = {plate_sep}", "font_size": 14},
                style={"fill": "#333", "font_family": "Arial"}
            )
            scene_objects.append(sep_label)

        # Add PLATE AREA annotation
        if plate_area:
            area_label = SceneObject(
                id="area_label",
                type=PrimitiveType.TEXT,
                position={"x": self.center_x, "y": self.center_y - 120},
                properties={"text": f"Area A = {plate_area}", "font_size": 14},
                style={"fill": "#333", "font_family": "Arial", "text_anchor": "middle"}
            )
            scene_objects.append(area_label)

        # Add VOLTAGE annotation
        if voltage:
            voltage_label = SceneObject(
                id="voltage_label",
                type=PrimitiveType.TEXT,
                position={"x": self.center_x + 200, "y": self.center_y},
                properties={"text": f"V = {voltage}", "font_size": 16, "font_weight": "bold"},
                style={"fill": "#e65100", "font_family": "Arial"}
            )
            scene_objects.append(voltage_label)

        # Add DIELECTRIC CONSTANT label
        if kappa:
            kappa_label = SceneObject(
                id="kappa_label",
                type=PrimitiveType.TEXT,
                position={"x": self.center_x, "y": self.center_y + 130},
                properties={"text": f"κ = {kappa}", "font_size": 14, "font_weight": "bold"},
                style={"fill": "#1565c0", "font_family": "Arial", "text_anchor": "middle"}
            )
            scene_objects.append(kappa_label)

        # Add dielectric thickness annotation
        if dielectric:
            thickness_label = SceneObject(
                id="thickness_label",
                type=PrimitiveType.TEXT,
                position={"x": self.center_x - 50, "y": self.center_y + 50},
                properties={"text": f"t = {di_props.get('thickness', '')}", "font_size": 12},
                style={"fill": "#42a5f5", "font_family": "Arial"}
            )
            scene_objects.append(thickness_label)

        return scene_objects, constraints

    def _create_circuit(self, objects: List[Dict], relationships: List[Dict]) -> tuple:
        """Create circuit with multiple capacitors"""
        scene_objects = []
        constraints = []

        # Identify capacitors
        capacitors = [obj for obj in objects if 'capacitor' in str(obj.get('type', '')).lower()]
        battery = next((obj for obj in objects if 'battery' in str(obj.get('type', '')).lower()), None)

        num_caps = len(capacitors)

        if num_caps == 2:
            # Two capacitors - likely series
            scene_objects, constraints = self._create_series_capacitors(capacitors, battery)
        elif num_caps == 3:
            # Three capacitors - check relationships for series/parallel
            scene_objects, constraints = self._create_three_capacitor_circuit(capacitors, relationships, battery)
        else:
            # Fallback to simple capacitor
            scene_objects, constraints = self._create_simple_capacitor(objects)

        return scene_objects, constraints

    def _create_series_capacitors(self, capacitors: List[Dict], battery: Optional[Dict]) -> tuple:
        """Create two capacitors in series"""
        scene_objects = []
        constraints = []

        # Battery on left
        if battery:
            voltage = battery.get('properties', {}).get('voltage', 0)
            battery_obj = SceneObject(
                id="battery",
                type=PrimitiveType.RECTANGLE,
                position={"x": 200, "y": self.center_y - 40},
                properties={"width": 30, "height": 80, "voltage": voltage},
                style={"fill": "#555", "stroke": "#333", "stroke_width": 2}
            )
            scene_objects.append(battery_obj)

        # Capacitor 1 (top)
        cap1_obj = SceneObject(
            id="capacitor_1",
            type=PrimitiveType.RECTANGLE,
            position={"x": 370, "y": 250},
            properties={"capacitance": capacitors[0].get('properties', {}).get('capacitance', 0)},
            style={"fill": "none", "stroke": "#2c3e50", "stroke_width": 4}
        )
        scene_objects.append(cap1_obj)

        # Capacitor 2 (bottom)
        cap2_obj = SceneObject(
            id="capacitor_2",
            type=PrimitiveType.RECTANGLE,
            position={"x": 620, "y": 250},
            properties={"capacitance": capacitors[1].get('properties', {}).get('capacitance', 0) if len(capacitors) > 1 else 0},
            style={"fill": "none", "stroke": "#2c3e50", "stroke_width": 4}
        )
        scene_objects.append(cap2_obj)

        # Add wires connecting them
        wires = [
            # Battery to C1
            {"id": "wire1", "x1": 230, "y1": self.center_y, "x2": 370, "y2": self.center_y},
            # C1 to C2
            {"id": "wire2", "x1": 430, "y1": self.center_y, "x2": 620, "y2": self.center_y},
            # C2 back to battery
            {"id": "wire3", "x1": 680, "y1": self.center_y, "x2": 750, "y2": self.center_y},
            {"id": "wire4", "x1": 750, "y1": self.center_y, "x2": 750, "y2": self.center_y + 200},
            {"id": "wire5", "x1": 750, "y1": self.center_y + 200, "x2": 200, "y2": self.center_y + 200},
            {"id": "wire6", "x1": 200, "y1": self.center_y + 200, "x2": 200, "y2": self.center_y + 40}
        ]

        for wire in wires:
            wire_obj = SceneObject(
                id=wire["id"],
                type=PrimitiveType.LINE,
                position={"x1": wire["x1"], "y1": wire["y1"], "x2": wire["x2"], "y2": wire["y2"]},
                properties={},
                style={"stroke": "#2c3e50", "stroke_width": 3}
            )
            scene_objects.append(wire_obj)

        return scene_objects, constraints

    def _create_three_capacitor_circuit(self, capacitors: List[Dict], relationships: List[Dict], battery: Optional[Dict]) -> tuple:
        """Create circuit with 3 capacitors (C1 in series with parallel C2||C3)"""
        # For now, create a simple layout
        # TODO: Parse relationships to determine exact topology
        scene_objects, constraints = self._create_series_capacitors(capacitors[:2], battery)
        return scene_objects, constraints
