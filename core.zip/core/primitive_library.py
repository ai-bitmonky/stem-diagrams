#!/usr/bin/env python3
"""
Primitive Diagram Component Library
=====================================

Reusable diagram components for consistency and efficiency.

Implements the roadmap's primitive library system:
- Store and index reusable diagram components
- Similarity search for component retrieval
- Automatic primitive extraction from existing diagrams
- Multi-modal embeddings (visual + text)

Author: Universal STEM Diagram Generator
Date: November 5, 2025
"""

import json
import hashlib
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
import logging

try:
    import sqlite3
    HAS_SQLITE = True
except ImportError:
    HAS_SQLITE = False

try:
    from sentence_transformers import SentenceTransformer
    HAS_TRANSFORMERS = True
except ImportError:
    HAS_TRANSFORMERS = False


@dataclass
class PrimitiveComponent:
    """A reusable diagram component"""
    id: str
    name: str
    description: str
    domain: str  # physics, electronics, chemistry, etc.
    category: str  # resistor, block, molecule, etc.
    svg_content: str
    metadata: Dict[str, Any]
    tags: List[str]
    embedding: Optional[List[float]] = None


class PrimitiveLibrary:
    """
    Library of reusable diagram primitives

    Provides:
    - Storage and retrieval of components
    - Similarity search
    - Component management
    """

    def __init__(
        self,
        library_path: str = "data/primitive_library",
        use_embeddings: bool = True
    ):
        """
        Initialize primitive library

        Args:
            library_path: Path to library storage
            use_embeddings: Use semantic embeddings for search
        """
        self.library_path = Path(library_path)
        self.library_path.mkdir(parents=True, exist_ok=True)

        self.db_path = self.library_path / "primitives.db"
        self.svg_dir = self.library_path / "svg"
        self.svg_dir.mkdir(exist_ok=True)

        self.logger = logging.getLogger(__name__)

        # Initialize database
        if HAS_SQLITE:
            self._init_database()
        else:
            self.logger.warning("SQLite not available, using in-memory storage")
            self.primitives = {}

        # Initialize embedding model for semantic search
        self.embedding_model = None
        if use_embeddings and HAS_TRANSFORMERS:
            try:
                self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
                self.logger.info("✓ Loaded embedding model for semantic search")
            except Exception as e:
                self.logger.warning(f"Could not load embedding model: {e}")

    def _init_database(self):
        """Initialize SQLite database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS primitives (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT,
                domain TEXT NOT NULL,
                category TEXT NOT NULL,
                svg_path TEXT NOT NULL,
                metadata TEXT,
                tags TEXT,
                embedding BLOB,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Create indices for fast search
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_domain ON primitives(domain)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_category ON primitives(category)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_tags ON primitives(tags)')

        conn.commit()
        conn.close()

        self.logger.info(f"✓ Initialized primitive library at {self.db_path}")

    def add_primitive(
        self,
        name: str,
        description: str,
        domain: str,
        category: str,
        svg_content: str,
        tags: List[str],
        metadata: Optional[Dict] = None
    ) -> str:
        """
        Add a primitive component to the library

        Args:
            name: Component name
            description: Component description
            domain: Domain (physics, electronics, etc.)
            category: Category (resistor, block, etc.)
            svg_content: SVG XML content
            tags: Search tags
            metadata: Additional metadata

        Returns:
            Primitive ID
        """
        # Generate ID from content hash
        content_hash = hashlib.md5(svg_content.encode()).hexdigest()
        primitive_id = f"{domain}_{category}_{content_hash[:8]}"

        # Generate embedding for semantic search
        embedding = None
        if self.embedding_model:
            text_for_embedding = f"{name} {description} {' '.join(tags)}"
            embedding = self.embedding_model.encode([text_for_embedding])[0].tolist()

        # Save SVG file
        svg_path = self.svg_dir / f"{primitive_id}.svg"
        svg_path.write_text(svg_content, encoding='utf-8')

        # Store in database
        if HAS_SQLITE:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute('''
                INSERT OR REPLACE INTO primitives
                (id, name, description, domain, category, svg_path, metadata, tags, embedding)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                primitive_id,
                name,
                description,
                domain,
                category,
                str(svg_path),
                json.dumps(metadata or {}),
                json.dumps(tags),
                json.dumps(embedding) if embedding else None
            ))

            conn.commit()
            conn.close()

        self.logger.info(f"✓ Added primitive: {primitive_id} ({name})")
        return primitive_id

    def search(
        self,
        query: str,
        domain: Optional[str] = None,
        category: Optional[str] = None,
        limit: int = 5
    ) -> List[PrimitiveComponent]:
        """
        Search for primitives

        Args:
            query: Search query (text or description)
            domain: Filter by domain
            category: Filter by category
            limit: Max results

        Returns:
            List of matching primitives
        """
        if not HAS_SQLITE:
            return []

        # Build SQL query
        sql = "SELECT * FROM primitives WHERE 1=1"
        params = []

        if domain:
            sql += " AND domain = ?"
            params.append(domain)

        if category:
            sql += " AND category = ?"
            params.append(category)

        # Text search in name, description, tags
        if query:
            sql += " AND (name LIKE ? OR description LIKE ? OR tags LIKE ?)"
            pattern = f"%{query}%"
            params.extend([pattern, pattern, pattern])

        sql += f" LIMIT {limit}"

        # Execute search
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        cursor.execute(sql, params)
        rows = cursor.fetchall()
        conn.close()

        # Convert to PrimitiveComponent objects
        results = []
        for row in rows:
            # Load SVG content
            svg_content = Path(row['svg_path']).read_text()

            results.append(PrimitiveComponent(
                id=row['id'],
                name=row['name'],
                description=row['description'],
                domain=row['domain'],
                category=row['category'],
                svg_content=svg_content,
                metadata=json.loads(row['metadata']),
                tags=json.loads(row['tags']),
                embedding=json.loads(row['embedding']) if row['embedding'] else None
            ))

        return results

    def semantic_search(
        self,
        query: str,
        domain: Optional[str] = None,
        limit: int = 5
    ) -> List[Tuple[PrimitiveComponent, float]]:
        """
        Semantic similarity search using embeddings

        Args:
            query: Query text
            domain: Filter by domain
            limit: Max results

        Returns:
            List of (primitive, similarity_score) tuples
        """
        if not self.embedding_model:
            # Fallback to regular search
            results = self.search(query, domain=domain, limit=limit)
            return [(p, 1.0) for p in results]

        # Generate query embedding
        query_embedding = self.embedding_model.encode([query])[0]

        # Get all primitives (with optional domain filter)
        sql = "SELECT * FROM primitives WHERE embedding IS NOT NULL"
        params = []

        if domain:
            sql += " AND domain = ?"
            params.append(domain)

        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        cursor.execute(sql, params)
        rows = cursor.fetchall()
        conn.close()

        # Calculate similarities
        results = []
        for row in rows:
            primitive_embedding = json.loads(row['embedding'])

            # Cosine similarity
            import numpy as np
            similarity = np.dot(query_embedding, primitive_embedding) / (
                np.linalg.norm(query_embedding) * np.linalg.norm(primitive_embedding)
            )

            # Load full primitive
            svg_content = Path(row['svg_path']).read_text()
            primitive = PrimitiveComponent(
                id=row['id'],
                name=row['name'],
                description=row['description'],
                domain=row['domain'],
                category=row['category'],
                svg_content=svg_content,
                metadata=json.loads(row['metadata']),
                tags=json.loads(row['tags']),
                embedding=primitive_embedding
            )

            results.append((primitive, float(similarity)))

        # Sort by similarity and return top results
        results.sort(key=lambda x: x[1], reverse=True)
        return results[:limit]

    def get_by_id(self, primitive_id: str) -> Optional[PrimitiveComponent]:
        """Get primitive by ID"""
        results = self.search("", limit=1000)  # Get all
        for primitive in results:
            if primitive.id == primitive_id:
                return primitive
        return None

    def list_domains(self) -> List[str]:
        """List available domains"""
        if not HAS_SQLITE:
            return []

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT domain FROM primitives")
        domains = [row[0] for row in cursor.fetchall()]
        conn.close()

        return domains

    def list_categories(self, domain: Optional[str] = None) -> List[str]:
        """List available categories"""
        if not HAS_SQLITE:
            return []

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        if domain:
            cursor.execute("SELECT DISTINCT category FROM primitives WHERE domain = ?", (domain,))
        else:
            cursor.execute("SELECT DISTINCT category FROM primitives")

        categories = [row[0] for row in cursor.fetchall()]
        conn.close()

        return categories

    def count(self, domain: Optional[str] = None) -> int:
        """Count primitives in library"""
        if not HAS_SQLITE:
            return 0

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        if domain:
            cursor.execute("SELECT COUNT(*) FROM primitives WHERE domain = ?", (domain,))
        else:
            cursor.execute("SELECT COUNT(*) FROM primitives")

        count = cursor.fetchone()[0]
        conn.close()

        return count

    def bootstrap_library(self):
        """Bootstrap library with common components"""
        self.logger.info("Bootstrapping primitive library with common components...")

        # Electronics components
        self._add_resistor_primitives()
        self._add_capacitor_primitives()
        self._add_battery_primitives()

        # Physics components
        self._add_block_primitives()
        self._add_force_primitives()

        self.logger.info(f"✓ Bootstrapped library with {self.count()} primitives")

    def _add_resistor_primitives(self):
        """Add common resistor symbols"""
        # Standard resistor (zigzag)
        resistor_svg = '''<svg xmlns="http://www.w3.org/2000/svg" width="60" height="20">
          <path d="M 0 10 L 10 10 L 15 5 L 20 15 L 25 5 L 30 15 L 35 5 L 40 15 L 45 5 L 50 10 L 60 10"
                stroke="#000" stroke-width="2" fill="none"/>
        </svg>'''

        self.add_primitive(
            name="Standard Resistor",
            description="Standard zigzag resistor symbol",
            domain="electronics",
            category="resistor",
            svg_content=resistor_svg,
            tags=["resistor", "passive", "component", "resistance"],
            metadata={"style": "american", "variant": "standard"}
        )

    def _add_capacitor_primitives(self):
        """Add capacitor symbols"""
        capacitor_svg = '''<svg xmlns="http://www.w3.org/2000/svg" width="40" height="30">
          <line x1="0" y1="15" x2="15" y2="15" stroke="#000" stroke-width="2"/>
          <line x1="15" y1="5" x2="15" y2="25" stroke="#000" stroke-width="2"/>
          <line x1="25" y1="5" x2="25" y2="25" stroke="#000" stroke-width="2"/>
          <line x1="25" y1="15" x2="40" y2="15" stroke="#000" stroke-width="2"/>
        </svg>'''

        self.add_primitive(
            name="Standard Capacitor",
            description="Non-polarized capacitor symbol with parallel plates",
            domain="electronics",
            category="capacitor",
            svg_content=capacitor_svg,
            tags=["capacitor", "passive", "component"],
            metadata={"style": "standard", "polarized": False}
        )

    def _add_battery_primitives(self):
        """Add battery symbols"""
        battery_svg = '''<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40">
          <line x1="15" y1="10" x2="15" y2="30" stroke="#000" stroke-width="3"/>
          <line x1="25" y1="15" x2="25" y2="25" stroke="#000" stroke-width="2"/>
          <line x1="0" y1="20" x2="15" y2="20" stroke="#000" stroke-width="2"/>
          <line x1="25" y1="20" x2="40" y2="20" stroke="#000" stroke-width="2"/>
          <text x="10" y="8" font-size="12">+</text>
        </svg>'''

        self.add_primitive(
            name="Battery",
            description="Battery or DC voltage source",
            domain="electronics",
            category="battery",
            svg_content=battery_svg,
            tags=["battery", "voltage source", "power"],
            metadata={"type": "dc", "symbol": "standard"}
        )

    def _add_block_primitives(self):
        """Add physics block symbols"""
        block_svg = '''<svg xmlns="http://www.w3.org/2000/svg" width="60" height="40">
          <rect x="5" y="5" width="50" height="30" fill="#ddd" stroke="#000" stroke-width="2"/>
          <text x="30" y="25" text-anchor="middle" font-size="14">m</text>
        </svg>'''

        self.add_primitive(
            name="Physics Block",
            description="Rectangular block for mechanics problems",
            domain="physics",
            category="block",
            svg_content=block_svg,
            tags=["block", "mass", "object", "mechanics"],
            metadata={"type": "solid", "3d": False}
        )

    def _add_force_primitives(self):
        """Add force vector symbols"""
        force_svg = '''<svg xmlns="http://www.w3.org/2000/svg" width="60" height="10">
          <defs>
            <marker id="arrowhead" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
              <polygon points="0 0, 10 3, 0 6" fill="#e74c3c"/>
            </marker>
          </defs>
          <line x1="0" y1="5" x2="50" y2="5" stroke="#e74c3c" stroke-width="2" marker-end="url(#arrowhead)"/>
          <text x="25" y="2" text-anchor="middle" font-size="10" fill="#e74c3c">F</text>
        </svg>'''

        self.add_primitive(
            name="Force Vector",
            description="Force arrow for free-body diagrams",
            domain="physics",
            category="force",
            svg_content=force_svg,
            tags=["force", "vector", "arrow", "mechanics"],
            metadata={"type": "vector", "color": "red"}
        )


if __name__ == "__main__":
    # Test primitive library
    logging.basicConfig(level=logging.INFO)

    print("=" * 60)
    print("PRIMITIVE LIBRARY TEST")
    print("=" * 60)

    library = PrimitiveLibrary(library_path="test_primitives")

    # Bootstrap with common components
    library.bootstrap_library()

    print(f"\n✓ Library contains {library.count()} primitives")
    print(f"✓ Domains: {', '.join(library.list_domains())}")

    # Test search
    print("\n" + "=" * 60)
    print("Testing search...")
    print("=" * 60)

    results = library.search("resistor", domain="electronics")
    print(f"\n✓ Found {len(results)} resistor primitives:")
    for primitive in results:
        print(f"   - {primitive.name} ({primitive.id})")
        print(f"     Tags: {', '.join(primitive.tags)}")

    # Test semantic search if available
    if library.embedding_model:
        print("\n" + "=" * 60)
        print("Testing semantic search...")
        print("=" * 60)

        results = library.semantic_search("component for measuring resistance")
        print(f"\n✓ Semantic search results:")
        for primitive, score in results:
            print(f"   - {primitive.name} (similarity: {score:.3f})")

    print("\n" + "=" * 60)
    print("✅ Primitive Library ready")
    print("=" * 60)

    print("\n📝 Usage:")
    print("   library.add_primitive(...) to add new components")
    print("   library.search('resistor') for keyword search")
    print("   library.semantic_search('...') for semantic search")
