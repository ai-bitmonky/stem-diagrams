"""
Universal Validator - Single Robust Pipeline Phase 3
Merges semantic, geometric, and physics validation into one unified validator
Uses data-driven rules from domains/*/rules.json
"""

from typing import Dict, List, Tuple
from pathlib import Path
import json

from core.scene.schema_v1 import Scene, SceneObject, Constraint, ConstraintType
from core.universal_ai_analyzer import CanonicalProblemSpec, PhysicsDomain
# from core.validator import SceneValidator  # Not using for now


class ValidationReport:
    """Complete validation report"""

    def __init__(self):
        self.errors: List[str] = []
        self.warnings: List[str] = []
        self.info: List[str] = []
        self.auto_corrections: List[str] = []
        self.is_valid: bool = True

    def add_error(self, message: str):
        """Add error (halts generation)"""
        self.errors.append(message)
        self.is_valid = False

    def add_warning(self, message: str):
        """Add warning (continues generation)"""
        self.warnings.append(message)

    def add_info(self, message: str):
        """Add info (informational only)"""
        self.info.append(message)

    def add_correction(self, message: str):
        """Log auto-correction"""
        self.auto_corrections.append(message)

    def __repr__(self):
        status = "✅ VALID" if self.is_valid else "❌ INVALID"
        summary = f"{status}\n"
        if self.errors:
            summary += f"Errors: {len(self.errors)}\n"
        if self.warnings:
            summary += f"Warnings: {len(self.warnings)}\n"
        if self.auto_corrections:
            summary += f"Auto-corrections: {len(self.auto_corrections)}\n"
        return summary


class UniversalValidator:
    """
    Universal Validator - Single robust implementation

    Merges:
    - core.validator.Validator (semantic + geometric checks)
    - PhysicsRuleValidator (domain-specific physics)
    - BidirectionalValidator (AI-based quality checking)

    Uses data-driven rules from domains/*/rules.json
    Auto-corrects where possible, fails clearly otherwise
    """

    def __init__(self, mode: str = "standard", domains_path: str = "domains"):
        """
        Initialize Universal Validator

        Args:
            mode: Validation mode (strict, standard, permissive)
            domains_path: Path to domains directory with rules
        """
        self.mode = mode
        self.domains_path = Path(domains_path)

        # Load domain validators
        self.domain_validators = self._load_domain_validators()

        print(f"✅ UniversalValidator initialized")
        print(f"   Mode: {mode}")
        print(f"   Loaded {len(self.domain_validators)} domain validators")

    def validate(self, scene: Scene, spec: CanonicalProblemSpec) -> Tuple[ValidationReport, Scene]:
        """
        Validate scene against specifications

        Pipeline:
        1. Semantic checks (structure)
        2. Geometric checks (layout)
        3. Domain-specific physics checks
        4. Auto-correction (where possible)
        5. Final validation

        Args:
            scene: Scene to validate
            spec: Original problem specification

        Returns:
            Tuple of (ValidationReport, corrected_scene)
        """
        print(f"\n{'='*80}")
        print(f"✅ UNIVERSAL VALIDATION - Phase 3")
        print(f"{'='*80}\n")

        report = ValidationReport()

        # Step 1: Semantic checks
        print("Step 1/5: Semantic Validation")
        self._validate_semantic(scene, spec, report)
        print(f"   ✅ Semantic: {len(report.errors)} errors, {len(report.warnings)} warnings")

        # Step 2: Geometric checks
        print("\nStep 2/5: Geometric Validation")
        self._validate_geometric(scene, report)
        print(f"   ✅ Geometric: {len(report.errors)} errors, {len(report.warnings)} warnings")

        # Step 3: Domain-specific physics checks
        print("\nStep 3/5: Domain-Specific Physics Validation")
        self._validate_physics(scene, spec, report)
        print(f"   ✅ Physics: {len(report.errors)} errors, {len(report.warnings)} warnings")

        # Step 4: Auto-correction
        print("\nStep 4/5: Auto-Correction")
        corrected_scene = self._auto_correct(scene, report)
        if report.auto_corrections:
            print(f"   ✅ Applied {len(report.auto_corrections)} auto-corrections")
        else:
            print(f"   ✅ No corrections needed")

        # Step 5: Final validation
        print("\nStep 5/5: Final Validation")
        if report.is_valid:
            print(f"   ✅ Scene is VALID")
        else:
            print(f"   ❌ Scene is INVALID ({len(report.errors)} errors)")

        print(f"\n{'='*80}")
        if report.is_valid:
            print(f"✅ UNIVERSAL VALIDATION PASSED")
        else:
            print(f"❌ UNIVERSAL VALIDATION FAILED")
        print(f"{'='*80}\n")

        return report, corrected_scene

    def _load_domain_validators(self) -> Dict:
        """Load domain-specific validators from rules.json"""

        validators = {}

        # TODO: Implement domain-specific validators
        # For now, return empty dict
        return validators

    def _validate_semantic(self, scene: Scene, spec: CanonicalProblemSpec, report: ValidationReport):
        """Step 1: Semantic validation (structure)"""

        # Check minimum objects
        if len(scene.objects) < 1:
            report.add_error("Scene has no objects")

        # Check object IDs are unique
        ids = [obj.id for obj in scene.objects]
        if len(ids) != len(set(ids)):
            report.add_error("Duplicate object IDs found")

        # Check for required primitives
        for obj in scene.objects:
            if not hasattr(obj, 'type') or obj.type is None:
                report.add_error(f"Object {obj.id} is missing a primitive type.")

        # Check constraint references valid objects
        for constraint in scene.constraints:
            for obj_id in constraint.objects:
                if obj_id not in ids:
                    report.add_error(f"Constraint references non-existent object: {obj_id}")

        # Domain-specific semantic checks
        if spec.domain == PhysicsDomain.CURRENT_ELECTRICITY:
            # Check for power source
            has_power = any(obj.type == PrimitiveType.BATTERY_SYMBOL for obj in scene.objects)
            if not has_power:
                report.add_error("Circuit diagram missing power source")
        elif spec.domain == PhysicsDomain.MECHANICS:
            # Check for masses
            has_mass = any(obj.type == PrimitiveType.MASS for obj in scene.objects)
            if not has_mass:
                report.add_warning("Mechanics problem missing mass information")
        elif spec.domain == PhysicsDomain.OPTICS:
            has_lens_or_mirror = any(obj.type in [PrimitiveType.LENS, PrimitiveType.MIRROR] for obj in scene.objects)
            if not has_lens_or_mirror:
                report.add_error("Optics problem missing a lens or mirror.")

    def _validate_geometric(self, scene: Scene, report: ValidationReport):
        """Step 2: Geometric validation (layout)"""

        # Check for overlapping objects (if positions are set)
        positioned_objects = [obj for obj in scene.objects if obj.position]

        for i, obj1 in enumerate(positioned_objects):
            for obj2 in positioned_objects[i+1:]:
                if self._objects_overlap(obj1, obj2):
                    report.add_warning(f"Objects {obj1.id} and {obj2.id} overlap")

        # Check canvas bounds
        canvas_width = scene.coord_system.get('extent', [1200, 800])[0]
        canvas_height = scene.coord_system.get('extent', [1200, 800])[1]

        for obj in positioned_objects:
            pos = obj.position
            x = pos.get('x', 0)
            y = pos.get('y', 0)

            if x < 0 or y < 0:
                report.add_error(f"Object {obj.id} outside canvas (negative position)")
            elif x > canvas_width or y > canvas_height:
                report.add_error(f"Object {obj.id} outside canvas bounds")

        # Check constraints are satisfied
        for constraint in scene.constraints:
            if constraint.type == ConstraintType.DISTANCE:
                obj1 = self._get_obj(scene, constraint.objects[0])
                obj2 = self._get_obj(scene, constraint.objects[1])
                if obj1 and obj2 and obj1.position and obj2.position:
                    dist = self._distance(obj1, obj2)
                    if abs(dist - constraint.value) > 1e-2:
                        report.add_warning(f"Distance constraint between {obj1.id} and {obj2.id} not satisfied.")
            elif constraint.type == ConstraintType.ALIGNED_H:
                objs = [self._get_obj(scene, oid) for oid in constraint.objects]
                if len(objs) > 1 and all(o and o.position for o in objs):
                    y_vals = [o.position.get('y', 0) for o in objs]
                    if max(y_vals) - min(y_vals) > 1e-2:
                        report.add_warning(f"Horizontal alignment constraint not satisfied for objects {constraint.objects}")
            elif constraint.type == ConstraintType.ALIGNED_V:
                objs = [self._get_obj(scene, oid) for oid in constraint.objects]
                if len(objs) > 1 and all(o and o.position for o in objs):
                    x_vals = [o.position.get('x', 0) for o in objs]
                    if max(x_vals) - min(x_vals) > 1e-2:
                        report.add_warning(f"Vertical alignment constraint not satisfied for objects {constraint.objects}")

    def _validate_physics(self, scene: Scene, spec: CanonicalProblemSpec, report: ValidationReport):
        """Step 3: Domain-specific physics validation"""

        # Use domain-specific validator if available
        if spec.domain in self.domain_validators:
            validator = self.domain_validators[spec.domain]

            # Convert scene to dict for validator
            scene_dict = {
                'objects': [self._object_to_dict(obj) for obj in scene.objects],
                'constraints': [self._constraint_to_dict(c) for c in scene.constraints],
                'metadata': scene.metadata
            }

            # Run validation
            is_valid, results = validator.validate(scene_dict, check_type="all")

            # Process results
            for result in results:
                if not result.passed:
                    if result.severity == 'error':
                        report.add_error(result.message)
                    elif result.severity == 'warning':
                        report.add_warning(result.message)
                    else:
                        report.add_info(result.message)

        # General physics checks (all domains)
        self._validate_physics_general(scene, spec, report)

    def _validate_physics_general(self, scene: Scene, spec: CanonicalProblemSpec, report: ValidationReport):
        """General physics validation (all domains)"""

        # Check for dimensional consistency
        for obj in scene.objects:
            props = obj.properties

            # Check units are consistent
            if 'value' in props and 'unit' in props:
                # Validate unit is appropriate for property type
                pass  # TODO: Implement unit validation

        # Check for physical plausibility
        if spec.domain == PhysicsDomain.MECHANICS:
            # Check forces are balanced (if equilibrium)
            if 'equilibrium' in spec.physics_context.get('analysis_type', '').lower():
                # TODO: Verify sum of forces = 0
                pass

        elif spec.domain == PhysicsDomain.CURRENT_ELECTRICITY:
            # Check KCL/KVL if values provided
            # TODO: Implement circuit law validation
            pass
            
        elif spec.domain == PhysicsDomain.OPTICS:
            # Check thin-lens equation
            lens = next((obj for obj in scene.objects if obj.type == PrimitiveType.LENS), None)
            obj = next((obj for obj in scene.objects if obj.properties.get('is_object')), None)
            img = next((obj for obj in scene.objects if obj.properties.get('is_image')), None)

            if lens and obj and img and lens.position and obj.position and img.position:
                f = lens.properties.get('focal_length')
                do = abs(obj.position['x'] - lens.position['x'])
                di = abs(img.position['x'] - lens.position['x'])

                if f and do > 0 and di > 0:
                    if abs(1/f - (1/do + 1/di)) > 0.01:
                        report.add_warning("Thin-lens equation not satisfied.")

    def _auto_correct(self, scene: Scene, report: ValidationReport) -> Scene:
        """Step 4: Auto-correct scene where possible"""

        corrected = scene

        # Fix duplicate IDs
        ids = [obj.id for obj in scene.objects]
        if len(ids) != len(set(ids)):
            seen = set()
            for obj in corrected.objects:
                if obj.id in seen:
                    new_id = f"{obj.id}_{len(seen)}"
                    obj.id = new_id
                    report.add_correction(f"Fixed duplicate ID: {obj.id} → {new_id}")
                seen.add(obj.id)

        # Add missing constraints
        if not corrected.constraints:
            # Add NO_OVERLAP constraint for all objects
            from core.scene.schema_v1 import ConstraintType
            corrected.constraints.append(Constraint(
                type=ConstraintType.NO_OVERLAP,
                objects=[obj.id for obj in corrected.objects]
            ))
            report.add_correction("Added NO_OVERLAP constraint for all objects")

        # Add missing labels
        for obj in corrected.objects:
            if not obj.properties.get('label'):
                obj.properties['label'] = f"{obj.type.value.replace('_', ' ').title()}: {obj.id}"
                report.add_correction(f"Added missing label for object {obj.id}")

        return corrected

    def _get_obj(self, scene: Scene, obj_id: str) -> SceneObject:
        """Get object by ID from scene"""
        for obj in scene.objects:
            if obj.id == obj_id:
                return obj
        return None

    def _distance(self, obj1: SceneObject, obj2: SceneObject) -> float:
        """Calculate Euclidean distance between two objects"""
        if not obj1.position or not obj2.position:
            return 0.0

        x1 = obj1.position.get('x', 0)
        y1 = obj1.position.get('y', 0)
        x2 = obj2.position.get('x', 0)
        y2 = obj2.position.get('y', 0)

        import math
        return math.sqrt((x2 - x1)**2 + (y2 - y1)**2)

    def _objects_overlap(self, obj1: SceneObject, obj2: SceneObject) -> bool:
        """Check if two objects overlap"""

        if not obj1.position or not obj2.position:
            return False

        x1 = obj1.position.get('x', 0)
        y1 = obj1.position.get('y', 0)
        w1 = obj1.position.get('width', 20)
        h1 = obj1.position.get('height', 20)

        x2 = obj2.position.get('x', 0)
        y2 = obj2.position.get('y', 0)
        w2 = obj2.position.get('width', 20)
        h2 = obj2.position.get('height', 20)

        # Check overlap
        return not (x1 + w1 < x2 or x2 + w2 < x1 or y1 + h1 < y2 or y2 + h2 < y1)

    def _object_to_dict(self, obj: SceneObject) -> Dict:
        """Convert SceneObject to dict"""
        return {
            'id': obj.id,
            'type': obj.type.value if hasattr(obj.type, 'value') else str(obj.type),
            'properties': obj.properties,
            'position': obj.position,
            'style': obj.style
        }

    def _constraint_to_dict(self, constraint: Constraint) -> Dict:
        """Convert Constraint to dict"""
        return {
            'type': constraint.type.value if hasattr(constraint.type, 'value') else str(constraint.type),
            'objects': constraint.objects,
            'value': constraint.value
        }
