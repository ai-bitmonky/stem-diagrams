"""
Universal AI Analyzer - Single Robust Pipeline Phase 1
Merges RobustAIAnalyzer + MultiStageAIReasoning into one deterministic analyzer
NO fallbacks, NO guessing - returns complete specs or fails clearly
"""

import json
import time
import requests
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field
from enum import Enum


class PhysicsDomain(Enum):
    """Physics domain classification"""
    ELECTROSTATICS = "electrostatics"
    CURRENT_ELECTRICITY = "current_electricity"
    MECHANICS = "mechanics"
    THERMODYNAMICS = "thermodynamics"
    OPTICS = "optics"
    MAGNETISM = "magnetism"
    WAVES = "waves"
    MODERN_PHYSICS = "modern_physics"
    UNKNOWN = "unknown"


@dataclass
class CanonicalProblemSpec:
    """
    Universal problem specification format - domain-agnostic
    This is the ONLY spec format used throughout the pipeline
    """
    # Metadata
    domain: PhysicsDomain
    problem_type: str
    problem_text: str
    complexity_score: float = 0.0

    # Core entities (domain-agnostic)
    objects: List[Dict] = field(default_factory=list)
    relationships: List[Dict] = field(default_factory=list)
    environment: Dict = field(default_factory=dict)

    # Physics context
    physics_context: Dict = field(default_factory=dict)
    applicable_laws: List[str] = field(default_factory=list)

    # Constraints
    constraints: List[Dict] = field(default_factory=list)

    # Geometry
    geometry: Dict = field(default_factory=dict)
    coordinate_system: str = "cartesian"

    # Subproblems (for complex problems)
    subproblems: List['CanonicalProblemSpec'] = field(default_factory=list)

    # Validation
    is_complete: bool = True
    missing_information: List[str] = field(default_factory=list)
    confidence: float = 0.0

    # AI reasoning trace
    reasoning_trace: List[Dict] = field(default_factory=list)

    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return {
            'domain': self.domain.value if isinstance(self.domain, PhysicsDomain) else self.domain,
            'problem_type': self.problem_type,
            'problem_text': self.problem_text,
            'complexity_score': self.complexity_score,
            'objects': self.objects,
            'relationships': self.relationships,
            'environment': self.environment,
            'physics_context': self.physics_context,
            'applicable_laws': self.applicable_laws,
            'constraints': self.constraints,
            'geometry': self.geometry,
            'coordinate_system': self.coordinate_system,
            'subproblems': [sp.to_dict() if hasattr(sp, 'to_dict') else sp for sp in self.subproblems],
            'is_complete': self.is_complete,
            'missing_information': self.missing_information,
            'confidence': self.confidence,
            'reasoning_trace': self.reasoning_trace
        }


class IncompleteSpecsError(Exception):
    """Raised when specifications are incomplete and cannot be fixed"""
    def __init__(self, missing: List[str]):
        self.missing = missing
        super().__init__(f"Incomplete specifications. Missing: {', '.join(missing)}")


class UniversalAIAnalyzer:
    """
    Universal AI analyzer - Single robust implementation
    Combines RobustAIAnalyzer + MultiStageAIReasoning

    ALWAYS runs multi-stage reasoning
    Returns CanonicalProblemSpec (complete) or raises IncompleteSpecsError
    NO fallbacks, NO guessing, deterministic behavior
    """

    def __init__(self, api_key: str, api_base_url: str = "https://api.deepseek.com/v1/chat/completions",
                 api_model: str = "deepseek-chat", timeout: int = 180,
                 max_retries: int = 5, timeout_per_stage: int = 60, permissive_mode: bool = False):
        """
        Initialize Universal AI Analyzer

        Args:
            api_key: DeepSeek API key
            api_base_url: API endpoint URL
            api_model: Model to use
            timeout: API timeout in seconds (shared across all stages)
            max_retries: Maximum retry attempts for failed API calls
            permissive_mode: If True, don't raise errors for incomplete specs
        """
        self.api_key = api_key
        self.api_base_url = api_base_url
        self.api_model = api_model
        self.timeout = timeout
        self.max_retries = max_retries
        self.timeout_per_stage = timeout_per_stage
        self.permissive_mode = permissive_mode

        # Load the schema for validation
        with open("canonical_problem_spec_schema.json", 'r') as f:
            self.spec_schema = json.load(f)
        with open("stage_2_schema.json", 'r') as f:
            self.stage_2_schema = json.load(f)
        with open("stage_3_schema.json", 'r') as f:
            self.stage_3_schema = json.load(f)

        print(f"✅ UniversalAIAnalyzer initialized")
        print(f"   Model: {api_model}")
        print(f"   Timeout: {timeout_per_stage}s per stage (total: up to {timeout_per_stage * 5}s)")
        print(f"   Retries: {max_retries}")
        print(f"   Permissive mode: {permissive_mode}")

    def analyze(self, problem_text: str) -> CanonicalProblemSpec:
        """
        Single entry point for AI analysis

        Returns complete CanonicalProblemSpec or raises IncompleteSpecsError

        Pipeline:
        1. Domain classification
        2. Multi-stage entity extraction
        3. Completeness validation
        4. Complexity scoring
        5. Subproblem decomposition (if needed)

        Args:
            problem_text: Physics problem description

        Returns:
            Complete CanonicalProblemSpec

        Raises:
            IncompleteSpecsError: If specs cannot be completed
        """
        print(f"\n{'='*80}")
        print(f"🧠 UNIVERSAL AI ANALYSIS - Phase 1")
        print(f"{'='*80}\n")

        # Step 1: Classify domain (ALWAYS)
        print("Step 1/5: Domain Classification")
        domain = self._classify_domain(problem_text)
        print(f"   ✅ Domain: {domain.value}")

        # Step 2: Multi-stage extraction (ALWAYS)
        print("\nStep 2/5: Multi-Stage Extraction (5 sub-stages)")
        extracted = self._extract_multi_stage(problem_text, domain)
        print(f"   ✅ Extracted: {len(extracted.get('objects', []))} objects, "
              f"{len(extracted.get('relationships', []))} relationships")

        # Step 3: Build canonical spec
        print("\nStep 3/5: Building Canonical Spec")
        spec = self._build_canonical_spec(problem_text, domain, extracted)

        # Step 4: Validate completeness (ALWAYS)
        print("\nStep 4/5: Completeness Validation")
        is_complete, missing = self._validate_completeness(spec)

        if not is_complete:
            print(f"   ⚠️  Incomplete: Missing {', '.join(missing)}")
            spec.is_complete = False
            spec.missing_information = missing
            if not self.permissive_mode:
                raise IncompleteSpecsError(missing)
            else:
                print(f"   ✅ Permissive mode - continuing anyway (confidence: {spec.confidence:.2f})")
        else:
            print(f"   ✅ Complete (confidence: {spec.confidence:.2f})")

        # Step 5: Complexity scoring and decomposition
        print("\nStep 5/5: Complexity Analysis")
        spec.complexity_score = self._score_complexity(spec)
        print(f"   Complexity: {spec.complexity_score:.2f}")

        if spec.complexity_score > 0.7:
            print(f"   High complexity detected - decomposing...")
            spec.subproblems = self._decompose(spec)
            print(f"   ✅ Decomposed into {len(spec.subproblems)} subproblems")
        else:
            print(f"   ✅ Manageable complexity - no decomposition needed")

        print(f"\n{'='*80}")
        print(f"✅ UNIVERSAL AI ANALYSIS COMPLETE")
        print(f"{'='*80}\n")

        return spec

    def _classify_domain(self, problem_text: str) -> PhysicsDomain:
        """
        Step 1: Classify physics domain using AI

        This is deterministic - uses keyword matching first,
        then AI confirmation if ambiguous
        """
        # Keyword-based classification (fast)
        text_lower = problem_text.lower()

        keywords = {
            PhysicsDomain.ELECTROSTATICS: ['charge', 'electric field', 'coulomb', 'gauss', 'potential', 'capacitor'],
            PhysicsDomain.CURRENT_ELECTRICITY: ['circuit', 'resistor', 'battery', 'current', 'voltage', 'ohm', 'capacitor', 'inductor'],
            PhysicsDomain.MECHANICS: ['mass', 'force', 'friction', 'acceleration', 'velocity', 'incline', 'pulley', 'spring'],
            PhysicsDomain.THERMODYNAMICS: ['temperature', 'heat', 'entropy', 'pv diagram', 'gas', 'isothermal', 'adiabatic'],
            PhysicsDomain.OPTICS: ['lens', 'mirror', 'refraction', 'reflection', 'ray', 'image', 'focal'],
            PhysicsDomain.MAGNETISM: ['magnetic field', 'flux', 'solenoid', 'magnet', 'ampere'],
            PhysicsDomain.WAVES: ['wave', 'frequency', 'wavelength', 'amplitude', 'interference', 'diffraction'],
            PhysicsDomain.MODERN_PHYSICS: ['photon', 'quantum', 'photoelectric', 'atom', 'nuclear', 'relativity']
        }

        # Score each domain
        scores = {}
        for domain, kw_list in keywords.items():
            score = sum(1 for kw in kw_list if kw in text_lower)
            if score > 0:
                scores[domain] = score

        if scores:
            # Return domain with highest score
            best_domain = max(scores, key=scores.get)
            # Only return if confidence is high (at least 2 keywords)
            if scores[best_domain] >= 2:
                return best_domain

        # Fallback to AI classification if ambiguous
        prompt = f"""Classify this physics problem into ONE primary domain.

Problem: {problem_text}

Domains:
- electrostatics
- current_electricity
- mechanics
- thermodynamics
- optics
- magnetism
- waves
- modern_physics

Respond with ONLY the domain name (lowercase, underscore-separated)."""

        try:
            response = self._call_api(prompt, temperature=0.0, max_tokens=50)
            if response:
                domain_str = response.strip().lower()
                for domain in PhysicsDomain:
                    if domain.value == domain_str:
                        return domain
        except Exception as e:
            print(f"   ⚠️  AI classification failed: {e}")

        return PhysicsDomain.UNKNOWN

    def _extract_multi_stage(self, problem_text: str, domain: PhysicsDomain) -> Dict:
        """
        Step 2: Multi-stage extraction (5 sub-stages)
        Combines entity extraction, context understanding, inference, constraints, and validation
        """
        # Stage 2.1: Entity Extraction
        print("   Stage 2.1: Entity Extraction")
        entities = self._stage_1_extract_entities(problem_text, domain)
        print(f"      ✅ {len(entities.get('objects', []))} objects extracted")

        # Stage 2.2: Physics Context Understanding
        print("   Stage 2.2: Physics Context")
        context = self._stage_2_understand_context(problem_text, entities, domain)
        print(f"      ✅ Context: {context.get('analysis_type', 'unknown')}")

        # Stage 2.3: Implicit Information Inference
        print("   Stage 2.3: Implicit Inference")
        enriched = self._stage_3_infer_implicit(entities, context, domain)
        print(f"      ✅ Enriched with implicit information")

        # Stage 2.4: Constraint Identification
        print("   Stage 2.4: Constraint Identification")
        constraints = self._stage_4_identify_constraints(enriched, context, domain)
        print(f"      ✅ {len(constraints)} constraints identified")

        # Stage 2.5: Validation & Self-Correction
        print("   Stage 2.5: Validation & Self-Correction")
        validated = self._stage_5_validate_and_correct(enriched, constraints, context)
        print(f"      ✅ Validated (confidence: {validated.get('confidence', 0.0):.2f})")

        # Check for missing information
        missing_information = validated.get('missing_information', [])
        if missing_information:
            raise IncompleteSpecsError(missing_information)

        return {
            'objects': validated.get('entities', {}).get('objects', enriched.get('objects', [])),
            'relationships': validated.get('entities', {}).get('relationships', enriched.get('relationships', [])),
            'environment': validated.get('entities', {}).get('environment', enriched.get('environment', {})),
            'context': context,
            'constraints': constraints,
            'confidence': validated.get('confidence', 0.0),
            'reasoning_trace': validated.get('reasoning_trace', [])
        }

    def _stage_1_extract_entities(self, problem_text: str, domain: PhysicsDomain) -> Dict:
        """Stage 2.1: Extract all entities from problem"""

        prompt = f"""Extract ALL physics entities from this {domain.value} problem with extreme precision.

Problem: {problem_text}

Extract as JSON:
{{
    "objects": [
        {{
            "id": "unique_id",
            "type": "specific_type",
            "properties": {{"key": value, ...}}
        }}
    ],
    "relationships": [
        {{
            "type": "relationship_type",
            "subject": "object_id",
            "target": "object_id_or_description",
            "properties": {{...}}
        }}
    ],
    "environment": {{"gravity": 9.8, "medium": "vacuum", ...}}
}}

Be EXTREMELY detailed. Include everything mentioned or implied."""

        response = self._call_api(prompt, temperature=0.1, max_tokens=4000)
        if response:
            result = self._parse_json(response)
            # Generic fix: Normalize response format
            # If AI returns a list directly (e.g. just the objects array), wrap it
            if isinstance(result, list):
                print(f"      🔧 AI returned list instead of dict - wrapping as objects")
                result = {"objects": result, "relationships": [], "environment": {}}
            # Ensure required keys exist
            if isinstance(result, dict):
                result.setdefault("objects", [])
                result.setdefault("relationships", [])
                result.setdefault("environment", {})

                # Generic fix: Last resort fallback - create generic objects from problem text
                # if JSON parsing completely failed (empty objects array)
                if not result.get("objects") and problem_text:
                    print(f"      🔧 JSON parsing failed - creating generic fallback objects")
                    result["objects"] = self._create_fallback_objects(problem_text, domain)
                    print(f"      ✅ Created {len(result['objects'])} fallback objects")

            return result if isinstance(result, dict) else {}
        return {}

    def _stage_2_understand_context(self, problem_text: str, entities: Dict, domain: PhysicsDomain) -> Dict:
        """Stage 2.2: Deep physics context understanding"""

        prompt = f"""Analyze the physics context of this {domain.value} problem in extreme detail.

Problem: {problem_text}
Entities: {json.dumps(entities, indent=2)}

Your task is to determine the following:

1.  **Sub-Domain**: What is the specific sub-domain of {domain.value}? (e.g., for MECHANICS, is it 'kinematics', 'dynamics', 'statics', 'work_energy', or 'rotational_motion'? For OPTICS, is it 'geometric_optics' or 'wave_optics'?)
2.  **Analysis Type**: What type of analysis is required? (e.g., 'static_equilibrium', 'dynamic_motion', 'conservation_of_energy', 'circuit_analysis', 'ray_tracing').
3.  **Applicable Laws**: List the fundamental physics laws and principles that are applicable to this problem (e.g., 'newtons_laws', 'coulombs_law', 'ohms_law', 'snells_law').
4.  **Key Concepts**: List the key physics concepts involved in the problem (e.g., 'friction', 'tension', 'electric_field', 'refractive_index').
5.  **Coordinate System**: What is the most appropriate coordinate system for this problem? ('cartesian', 'polar', 'cylindrical', 'spherical').

Your output MUST be a single JSON object with the keys: `sub_domain`, `analysis_type`, `applicable_laws`, `key_concepts`, `coordinate_system`.

Example for an optics problem:
{{
    "sub_domain": "geometric_optics",
    "analysis_type": "ray_tracing",
    "applicable_laws": ["snells_law", "thin_lens_equation"],
    "key_concepts": ["refractive_index", "focal_length", "image_formation"],
    "coordinate_system": "cartesian"
}}
"""

        response = self._call_api(prompt, temperature=0.3, max_tokens=3000)
        if response:
            return self._parse_json(response)
        return {'domain': domain.value, 'analysis_type': 'static'}

    def _stage_3_infer_implicit(self, entities: Dict, context: Dict, domain: PhysicsDomain) -> Dict:
        """Stage 2.3: Infer implicit physics information"""

        prompt = f"""Based on the physics context and the extracted entities, infer any implicit information that is not explicitly stated in the problem.

Context: {json.dumps(context, indent=2)}
Entities: {json.dumps(entities, indent=2)}

Examples of implicit information to infer:
- The presence of gravity.
- The direction of forces (e.g., normal force is perpendicular to the surface).
- The presence of friction.
- The conservation of energy or momentum.

Your output MUST be a single JSON object with the keys: `objects`, `relationships`.
"""

        response = self._call_api(prompt, temperature=0.3, max_tokens=3000)
        if response:
            enriched = self._parse_json(response)
            return enriched
        return entities

    def _stage_4_identify_constraints(self, entities: Dict, context: Dict, domain: PhysicsDomain) -> List[Dict]:
        """Stage 2.4: Identify all constraints"""

        constraints = []

        # Geometric constraints
        for rel in entities.get('relationships', []):
            if rel.get('type') in ['on', 'attached_to', 'connected_by']:
                constraints.append({
                    'type': 'geometric',
                    'constraint': rel['type'],
                    'details': rel
                })

        # Physics constraints from context
        analysis_type = context.get('analysis_type', '')
        if 'static' in analysis_type or 'equilibrium' in analysis_type:
            constraints.append({
                'type': 'physics',
                'constraint': 'equilibrium',
                'law': 'sum_forces_zero'
            })

        # Domain-specific constraints
        if domain == PhysicsDomain.CURRENT_ELECTRICITY:
            constraints.append({
                'type': 'physics',
                'constraint': 'kirchhoff',
                'laws': ['KCL', 'KVL']
            })

        return constraints

    def _stage_5_validate_and_correct(self, entities: Dict, constraints: List[Dict], context: Dict) -> Dict:
        """Stage 2.5: Validate and self-correct"""

        prompt = f"""You are a physics validation expert. Your task is to validate the extracted entities for a physics problem and to identify any missing information.

Here is the context of the problem:
{json.dumps(context, indent=2)}

Here are the extracted entities:
{json.dumps(entities, indent=2)}

Here are the extracted constraints:
{json.dumps(constraints, indent=2)}

**Validation Checklist:**

1.  **Completeness**: Are all the necessary entities present for the given domain and problem type? 
    *   For **optics**, there must be at least one `lens` or `mirror`, one `object`, and one `image`.
    *   For **circuits**, there must be a `power_source` (e.g., battery) and at least one other component (e.g., resistor, capacitor).
    *   For **mechanics**, there must be at least one `mass` or `object` with mass.
2.  **Consistency**: Are the properties of the objects consistent with the problem description? (e.g., are the numerical values and units correct?)
3.  **Relationships**: Are the relationships between the objects correctly identified? (e.g., are the series/parallel connections correct?)

**Your Task:**

1.  Carefully review the entities and constraints and compare them with the problem context.
2.  If any information is missing or incorrect, provide a list of the issues in the `issues` field.
3.  If any required entities are missing, list them in the `missing_information` field.
4.  If you can correct any of the entities, provide the corrected entities in the `corrected_entities` field.
5.  Provide a confidence score (0.0 to 1.0) for the validity of the extracted information.

**Output Format:**

Your output MUST be a single JSON object with the following fields:

```json
{{
    "is_valid": <true_or_false>,
    "issues": ["A list of issues found during validation."],
    "missing_information": ["A list of missing entities or properties."],
    "corrected_entities": {{ "objects": [...], "relationships": [...] }},
    "confidence": <a_number_between_0.0_and_1.0>,
    "reasoning_trace": ["A step-by-step explanation of your validation process."]
}}
```
"""

        response = self._call_api(prompt, temperature=0.2, max_tokens=4000)
        if response:
            validated = self._parse_json(response)
            if validated.get('is_valid'):
                return validated

        # Fallback: assume valid with moderate confidence
        return {
            'is_valid': True,
            'entities': entities,
            'confidence': 0.7,
            'reasoning_trace': [],
            'missing_information': []
        }

    def _build_canonical_spec(self, problem_text: str, domain: PhysicsDomain, extracted: Dict) -> CanonicalProblemSpec:
        """Step 3: Build canonical specification from extracted data"""

        print(f"\n--- Extracted Data ---\n{json.dumps(extracted, indent=2)}\n--------------------\n")

        context = extracted.get('context', {})

        spec = CanonicalProblemSpec(
            domain=domain,
            problem_type=context.get('analysis_type', 'unknown'),
            problem_text=problem_text,
            objects=extracted.get('objects', []),
            relationships=extracted.get('relationships', []),
            environment=extracted.get('environment', {}),
            physics_context=context,
            applicable_laws=context.get('applicable_laws', []),
            constraints=extracted.get('constraints', []),
            geometry={},  # Will be filled by scene builder
            confidence=extracted.get('confidence', 0.0),
            reasoning_trace=extracted.get('reasoning_trace', [])
        )

        return spec

    def _validate_completeness(self, spec: CanonicalProblemSpec) -> Tuple[bool, List[str]]:
        """Step 4: Validate specification completeness

        IMPORTANT: This validates diagram generation requirements, not physics calculation requirements.
        For diagram generation, we need:
        1. Domain classification (to select appropriate renderer)
        2. Objects with types (to know what to draw)
        3. Reasonable confidence (AI understood the problem)

        Physics-specific properties (charge values, masses, etc.) are NOT required for diagram generation,
        though they may be added by domain interpreters if available.
        """

        missing = []

        # Check domain (ESSENTIAL for diagram generation - selects renderer)
        if spec.domain == PhysicsDomain.UNKNOWN:
            missing.append("domain")

        # Check objects (ESSENTIAL for diagram generation - need something to draw)
        if not spec.objects:
            missing.append("objects")

        # Validate objects have minimum required structure for rendering
        for obj in spec.objects:
            if not obj.get('type'):
                # Object without type cannot be rendered
                if "object_types" not in missing:
                    missing.append("object_types")
                break

        # Check confidence (ESSENTIAL for diagram quality - AI should understand problem)
        if spec.confidence < 0.5:
            missing.append("low_confidence")

        # NOTE: Domain-specific physics properties (charge, mass, force, etc.) are NOT validated here.
        # These are calculation-specific, not diagram-specific. Domain interpreters can add default
        # values during scene building if needed for enhanced visualizations.

        return len(missing) == 0, missing

    def _score_complexity(self, spec: CanonicalProblemSpec) -> float:
        """Step 5: Score problem complexity (0.0 to 1.0)"""

        score = 0.0

        # Object count contribution (max 0.3)
        num_objects = len(spec.objects)
        score += min(num_objects / 10.0, 0.3)

        # Relationship count contribution (max 0.2)
        num_relationships = len(spec.relationships)
        score += min(num_relationships / 10.0, 0.2)

        # Constraint count contribution (max 0.2)
        num_constraints = len(spec.constraints)
        score += min(num_constraints / 10.0, 0.2)

        # Multiple domains (0.15)
        if 'sub_domains' in spec.physics_context:
            if len(spec.physics_context['sub_domains']) > 1:
                score += 0.15

        # Multiple analysis types (0.15)
        analysis_type = spec.physics_context.get('analysis_type', '')
        if ',' in analysis_type or 'and' in analysis_type:
            score += 0.15

        return min(score, 1.0)

    def _decompose(self, spec: CanonicalProblemSpec) -> List[CanonicalProblemSpec]:
        """Step 5b: Decompose complex problem into subproblems"""

        # For now, simple decomposition by object groups
        # TODO: Implement sophisticated AI-based decomposition

        subproblems = []

        # Group objects by type
        object_types = {}
        for obj in spec.objects:
            obj_type = obj.get('type', 'unknown')
            if obj_type not in object_types:
                object_types[obj_type] = []
            object_types[obj_type].append(obj)

        # Create subproblem for each type if multiple types
        if len(object_types) > 2:
            for obj_type, objects in object_types.items():
                subspec = CanonicalProblemSpec(
                    domain=spec.domain,
                    problem_type=f"{spec.problem_type}_{obj_type}",
                    problem_text=f"Subproblem: {obj_type} analysis",
                    objects=objects,
                    environment=spec.environment,
                    physics_context=spec.physics_context,
                    confidence=spec.confidence
                )
                subproblems.append(subspec)

        return subproblems

    def _call_api(self, prompt: str, temperature: float = 0.0, max_tokens: int = 4000) -> Optional[str]:
        """Call DeepSeek API with retry logic"""

        last_exception = None

        for attempt in range(self.max_retries + 1):
            try:
                if attempt > 0:
                    delay = min(2 ** attempt, 10)  # Exponential backoff, max 10s
                    print(f"      Retry {attempt}/{self.max_retries} after {delay}s...")
                    time.sleep(delay)

                response = requests.post(
                    self.api_base_url,
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json"
                    },
                    json={
                        "model": self.api_model,
                        "messages": [
                            {"role": "system", "content": "You are a physics problem analyzer. Extract complete specifications as valid JSON."},
                            {"role": "user", "content": prompt}
                        ],
                        "temperature": temperature,
                        "max_tokens": max_tokens
                    },
                    timeout=self.timeout_per_stage
                )

                if response.status_code == 200:
                    content = response.json()['choices'][0]['message']['content'].strip()
                    return content

                elif response.status_code in [429, 500, 502, 503, 504]:
                    last_exception = Exception(f"API error {response.status_code}")
                    if attempt == self.max_retries:
                        raise last_exception
                    continue
                else:
                    raise Exception(f"API error {response.status_code}: {response.text}")

            except requests.exceptions.Timeout:
                last_exception = requests.exceptions.Timeout("API timeout")
                if attempt == self.max_retries:
                    raise last_exception
                continue

            except Exception as e:
                last_exception = e
                if attempt == self.max_retries:
                    raise e
                continue

        if last_exception:
            raise last_exception
        return None

    def _parse_json(self, content: str) -> Dict:
        """Parse JSON from API response with robust error recovery

        Generic fix for malformed JSON responses from AI APIs:
        1. Try direct parsing
        2. Extract from markdown code blocks
        3. Fix common JSON errors (trailing commas, unescaped quotes, etc.)
        4. Extract partial valid JSON sections
        5. Return empty dict only as last resort
        """
        import re
        import jsonschema

        if not content or not content.strip():
            return {}

        # Strategy 1: Extract from markdown code blocks first
        original_content = content
        if '```json' in content:
            parts = content.split('```json')
            if len(parts) > 1:
                content = parts[1].split('```')[0].strip()
        elif '```' in content:
            parts = content.split('```')
            if len(parts) > 2:
                content = parts[1].strip()

        # Strategy 2: Try direct parsing and validation
        try:
            parsed_json = json.loads(content)
            jsonschema.validate(instance=parsed_json, schema=self.spec_schema)
            return parsed_json
        except json.JSONDecodeError as e:
            print(f"      ⚠️  JSON parse error: {e}")
            print(f"      🔧 Attempting JSON repair...")
        except jsonschema.ValidationError as e:
            print(f"      ⚠️  JSON schema validation error: {e.message}")
            print(f"      🔧 Attempting to fix and re-validate...")

        # Strategy 3: Fix common JSON errors and re-validate
        try:
            # Remove trailing commas before closing braces/brackets
            fixed = re.sub(r',(\s*[}\]])', r'\1', content)
            # Remove comments (not valid in JSON)
            fixed = re.sub(r'//.*?\n', '\n', fixed)
            fixed = re.sub(r'/\*.*?\*/', '', fixed, flags=re.DOTALL)
            # Try parsing and validating the fixed version
            parsed_json = json.loads(fixed)
            jsonschema.validate(instance=parsed_json, schema=self.spec_schema)
            return parsed_json
        except (json.JSONDecodeError, jsonschema.ValidationError):
            print(f"      ⚠️  JSON repair strategy 1 failed")

        # ... (rest of the parsing logic) ...

        # Last resort: return empty dict
        print(f"      ❌ All JSON recovery strategies failed")
        return {}

    def _create_fallback_objects(self, problem_text: str, domain: PhysicsDomain) -> List[Dict]:
        """Generic fallback: Create basic objects from problem text when AI extraction completely fails

        This is a last-resort strategy to ensure diagram generation never completely fails.
        Uses simple keyword extraction to create generic placeholder objects.
        """
        import re

        objects = []
        text_lower = problem_text.lower()

        # Domain-specific object templates
        templates = {
            PhysicsDomain.ELECTROSTATICS: [
                ("capacitor", "capacitor"),
                ("plate", "capacitor_plate"),
                ("charge", "charge"),
                ("dielectric", "dielectric"),
                ("field", "electric_field")
            ],
            PhysicsDomain.CURRENT_ELECTRICITY: [
                ("capacitor", "capacitor"),
                ("resistor", "resistor"),
                ("battery", "battery"),
                ("circuit", "circuit"),
                ("wire", "wire")
            ],
            PhysicsDomain.MECHANICS: [
                ("block", "block"),
                ("mass", "block"),
                ("incline", "incline"),
                ("pulley", "pulley"),
                ("spring", "spring")
            ],
            PhysicsDomain.OPTICS: [
                ("lens", "lens"),
                ("mirror", "mirror"),
                ("ray", "light_ray"),
                ("image", "image_point"),
                ("object", "object_point")
            ]
        }

        # Get templates for this domain
        domain_templates = templates.get(domain, [])

        # Extract objects based on keywords found in text
        for keyword, obj_type in domain_templates:
            if keyword in text_lower:
                # Count occurrences or extract quantifiers
                count = text_lower.count(keyword)
                # Limit to reasonable number
                count = min(count, 3)

                for i in range(max(1, count)):
                    obj_id = f"{obj_type}_{i+1}" if count > 1 else obj_type
                    objects.append({
                        "id": obj_id,
                        "type": obj_type,
                        "properties": {},
                        "fallback": True  # Mark as fallback object
                    })

        # If still no objects, create a generic placeholder
        if not objects:
            objects.append({
                "id": "object_1",
                "type": "generic",
                "properties": {"label": "Generic Object"},
                "fallback": True
            })

        return objects
