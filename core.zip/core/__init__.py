"""Core modules for universal diagram framework"""

# Import only modules that exist
# Scene module imports handled separately due to submodules

__all__ = []
