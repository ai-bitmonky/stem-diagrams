"""
Universal Scene Builder - Single Robust Pipeline Phase 2
Converts CanonicalProblemSpec to UniversalScene using domain interpreters
NO fallbacks, NO guessing - returns complete scene or fails clearly
"""

from typing import Dict, List, Optional
from pathlib import Path
import json

from core.universal_ai_analyzer import CanonicalProblemSpec, PhysicsDomain
from core.scene.schema_v1 import Scene, SceneObject, Constraint, PrimitiveType, ConstraintType


class IncompleteSceneError(Exception):
    """Raised when scene cannot be built completely"""
    def __init__(self, missing: List[str]):
        self.missing = missing
        super().__init__(f"Incomplete scene. Missing: {', '.join(missing)}")


class UniversalSceneBuilder:
    """
    Universal Scene Builder - Single robust implementation

    Converts CanonicalProblemSpec to Scene using MANDATORY domain interpreters
    Domain knowledge is DATA (interpreters, rules), not separate code paths

    ALWAYS returns complete Scene or raises IncompleteSceneError
    NO fallbacks, NO guessing
    """

    def __init__(self, domains_path: str = "domains"):
        """
        Initialize Universal Scene Builder

        Args:
            domains_path: Path to domains directory with interpreters
        """
        self.domains_path = Path(domains_path)

        # Load ALL domain interpreters (mandatory)
        self.interpreters = self._load_interpreters()

        # Load physics enrichment rules
        self.physics_rules = self._load_physics_rules()

        print(f"✅ UniversalSceneBuilder initialized")
        print(f"   Loaded {len(self.interpreters)} domain interpreters")
        print(f"   Domains: {', '.join(d.value if isinstance(d, PhysicsDomain) else str(d) for d in self.interpreters.keys())}")

    def build(self, spec: CanonicalProblemSpec) -> Scene:
        """
        Convert CanonicalProblemSpec to Scene

        Pipeline:
        1. Select domain interpreter
        2. Interpret spec to base scene
        3. Enrich with physics rules
        4. Infer missing constraints
        5. Validate completeness

        Args:
            spec: Complete CanonicalProblemSpec from UniversalAIAnalyzer

        Returns:
            Complete Scene

        Raises:
            IncompleteSceneError: If scene cannot be completed
        """
        print(f"\n{'='*80}")
        print(f"🏗️  UNIVERSAL SCENE BUILDING - Phase 2")
        print(f"{ '='*80}\n")

        # Step 1: Select interpreter
        print(f"Step 1/5: Domain Interpreter Selection")
        interpreter = self._select_interpreter(spec.domain)
        print(f"   ✅ Selected: {spec.domain.value} interpreter")

        # Step 2: Interpret spec to scene
        print(f"\nStep 2/5: Scene Interpretation")
        # Convert CanonicalProblemSpec to dict for legacy interpreters
        spec_dict = self._spec_to_dict(spec)
        scene = interpreter.interpret(spec_dict)
        print(f"   ✅ Generated: {len(scene.objects)} objects, {len(scene.constraints)} constraints")

        # Step 3: Enrich with physics rules
        print(f"\nStep 3/5: Physics Enrichment")
        scene = self._enrich_with_physics(scene, spec)
        print(f"   ✅ Enriched: {len(scene.objects)} objects (added implicit elements)")

        # Step 4: Infer missing constraints
        print(f"\nStep 4/5: Constraint Inference")
        scene = self._infer_constraints(scene, spec)
        print(f"   ✅ Inferred: {len(scene.constraints)} total constraints")

        # Step 5: Validate completeness
        print(f"\nStep 5/5: Scene Completeness Validation")
        is_complete, missing = self._validate_scene_completeness(scene, spec)

        if not is_complete:
            print(f"   ❌ Incomplete scene: Missing {', '.join(missing)}")
            raise IncompleteSceneError(missing)

        print(f"   ✅ Complete scene validated")

        print(f"\n{'='*80}")
        print(f"✅ UNIVERSAL SCENE BUILDING COMPLETE")
        print(f"{ '='*80}\n")

        return scene

    def _spec_to_dict(self, spec) -> Dict:
        """Convert CanonicalProblemSpec to dictionary for legacy interpreters"""
        from dataclasses import asdict

        # Convert dataclass to dict
        spec_dict = asdict(spec)

        # Ensure problem_text is available for interpreter matching
        if not spec_dict.get('problem_text'):
            spec_dict['problem_text'] = spec.problem_text if hasattr(spec, 'problem_text') else ""

        # Debug: print the converted dict keys
        print(f"   📋 Converted spec dict keys: {list(spec_dict.keys())[:10]}")
        print(f"   📝 Problem text available: {bool(spec_dict.get('problem_text'))}")

        return spec_dict

    def _load_interpreters(self) -> Dict:
        """Load all domain interpreters"""

        interpreters = {}
        loaded_interpreters = []

        # Load CapacitorInterpreter
        try:
            from core.interpreters.capacitor_interpreter import CapacitorInterpreter
            capacitor_interp = CapacitorInterpreter()
            interpreters[PhysicsDomain.ELECTROSTATICS] = capacitor_interp
            interpreters[PhysicsDomain.CURRENT_ELECTRICITY] = capacitor_interp
            loaded_interpreters.append("CapacitorInterpreter (electrostatics & circuits)")
        except ImportError as e:
            print(f"   ⚠️  Failed to load CapacitorInterpreter: {e}")

        # Load OpticsInterpreter
        try:
            from core.interpreters.optics_interpreter import OpticsInterpreter
            optics_interp = OpticsInterpreter()
            interpreters[PhysicsDomain.OPTICS] = optics_interp
            loaded_interpreters.append("OpticsInterpreter")
        except ImportError as e:
            print(f"   ⚠️  Failed to load OpticsInterpreter: {e}")

        # Load MechanicsInterpreter
        try:
            from core.interpreters.mechanics_interpreter import MechanicsInterpreter
            mechanics_interp = MechanicsInterpreter()
            interpreters[PhysicsDomain.MECHANICS] = mechanics_interp
            loaded_interpreters.append("MechanicsInterpreter")
        except ImportError as e:
            print(f"   ⚠️  Failed to load MechanicsInterpreter: {e}")

        # Print success message
        if loaded_interpreters:
            print(f"   ✅ Loaded interpreters: {', '.join(loaded_interpreters)}")

        # Add generic interpreter for domains without specific interpreters
        if PhysicsDomain.MECHANICS not in interpreters:
            interpreters[PhysicsDomain.MECHANICS] = GenericInterpreter("mechanics")
        if PhysicsDomain.OPTICS not in interpreters:
            interpreters[PhysicsDomain.OPTICS] = GenericInterpreter("optics")
        if PhysicsDomain.ELECTROSTATICS not in interpreters:
            interpreters[PhysicsDomain.ELECTROSTATICS] = GenericInterpreter("electrostatics")

        interpreters[PhysicsDomain.THERMODYNAMICS] = GenericInterpreter("thermodynamics")
        interpreters[PhysicsDomain.MAGNETISM] = GenericInterpreter("magnetism")
        interpreters[PhysicsDomain.WAVES] = GenericInterpreter("waves")
        interpreters[PhysicsDomain.MODERN_PHYSICS] = GenericInterpreter("modern_physics")

        return interpreters

    def _load_physics_rules(self) -> Dict:
        """Load physics enrichment rules from domain configs"""

        rules = {}

        # Try to load from domains/ directory
        for domain in PhysicsDomain:
            rules_file = self.domains_path / domain.value / "rules.json"
            if rules_file.exists():
                with open(rules_file) as f:
                    rules[domain] = json.load(f)

        return rules

    def _select_interpreter(self, domain: PhysicsDomain):
        """Step 1: Select appropriate interpreter for domain"""

        if domain in self.interpreters:
            return self.interpreters[domain]

        # Fallback to generic interpreter
        print(f"   ⚠️  No specific interpreter for {domain.value}, using generic")
        return GenericInterpreter(domain.value)

    def _enrich_with_physics(self, scene: Scene, spec: CanonicalProblemSpec) -> Scene:
        """Step 3: Enrich scene with implicit physics elements"""

        # Add implicit forces for mechanics
        if spec.domain == PhysicsDomain.MECHANICS:
            scene = self._add_implicit_forces(scene, spec)

        # Add field lines for electrostatics
        elif spec.domain == PhysicsDomain.ELECTROSTATICS:
            scene = self._add_field_lines(scene, spec)

        # Add current flow for circuits
        elif spec.domain == PhysicsDomain.CURRENT_ELECTRICITY:
            scene = self._add_current_flow(scene, spec)
            
        # Add focal points for optics
        elif spec.domain == PhysicsDomain.OPTICS:
            scene = self._add_focal_points(scene, spec)

        return scene

    def _add_implicit_forces(self, scene: Scene, spec: CanonicalProblemSpec) -> Scene:
        """Add implicit forces (gravity, normal, friction) for mechanics"""

        # Find all mass objects
        mass_objects = [obj for obj in scene.objects if 'mass' in obj.properties]

        for obj in mass_objects:
            mass = obj.properties.get('mass', 1.0)

            # Add gravity arrow
            scene.objects.append(SceneObject(
                id=f"force_gravity_{obj.id}",
                type=PrimitiveType.ARROW,
                properties={
                    "direction": "downward",
                    "magnitude": mass * 9.8,
                    "label": f"mg",
                    "color": "#cc0000",
                    "parent": obj.id,
                    "implicit": True
                }
            ))

            # If on surface, add normal force
            if any(rel.get('type') == 'on' and rel.get('subject') == obj.id
                   for rel in spec.relationships):
                scene.objects.append(SceneObject(
                    id=f"force_normal_{obj.id}",
                    type=PrimitiveType.ARROW,
                    properties={
                        "direction": "upward",
                        "magnitude": mass * 9.8,
                        "label": "N",
                        "color": "#0000cc",
                        "parent": obj.id,
                        "implicit": True
                    }
                ))

        return scene

    def _add_field_lines(self, scene: Scene, spec: CanonicalProblemSpec) -> Scene:
        """Add electric field lines for electrostatics"""

        # Find all charge objects
        charges = [obj for obj in scene.objects if obj.type == PrimitiveType.CHARGE]

        # Add field lines between charges
        for i, charge1 in enumerate(charges):
            for charge2 in charges[i+1:]:
                # Add field line
                scene.objects.append(SceneObject(
                    id=f"field_line_{charge1.id}_{charge2.id}",
                    type=PrimitiveType.FIELD_LINE,
                    properties={
                        "source": charge1.id,
                        "target": charge2.id,
                        "implicit": True
                    }
                ))

        return scene

    def _add_current_flow(self, scene: Scene, spec: CanonicalProblemSpec) -> Scene:
        """Add current flow indicators for circuits"""

        # Find battery/power source
        batteries = [obj for obj in scene.objects
                    if obj.type == PrimitiveType.BATTERY_SYMBOL or 'battery' in obj.properties]

        if batteries:
            # Add current flow arrow
            scene.objects.append(SceneObject(
                id="current_flow",
                type=PrimitiveType.ARROW,
                properties={
                    "label": "I",
                    "color": "#0066cc",
                    "implicit": True,
                    "style": "dashed"
                }
            ))

        return scene

    def _infer_constraints(self, scene: Scene, spec: CanonicalProblemSpec) -> Scene:
        """Step 4: Infer missing layout constraints"""

        # Infer alignment constraints
        objects_by_type = {}
        for obj in scene.objects:
            obj_type = obj.type
            if obj_type not in objects_by_type:
                objects_by_type[obj_type] = []
            objects_by_type[obj_type].append(obj)

        # Add alignment for similar objects
        for obj_type, objects in objects_by_type.items():
            if len(objects) >= 2:
                # Align horizontally if same type
                scene.constraints.append(Constraint(
                    type=ConstraintType.ALIGNED_H,
                    objects=[obj.id for obj in objects]
                ))

        # Infer distance constraints from relationships
        for rel in spec.relationships:
            if rel.get('type') == 'connected_by':
                # Add CONNECTED constraint
                scene.constraints.append(Constraint(
                    type=ConstraintType.CONNECTED,
                    objects=[rel['subject'], rel['target']]
                ))

        # Infer no-overlap for all objects
        if len(scene.objects) >= 2:
            scene.constraints.append(Constraint(
                type=ConstraintType.NO_OVERLAP,
                objects=[obj.id for obj in scene.objects]
            ))

        return scene

    def _validate_scene_completeness(self, scene: Scene, spec: CanonicalProblemSpec) -> tuple:
        """Step 5: Validate scene has all required elements for diagram rendering"""

        missing = []

        # Check objects (ESSENTIAL - need something to render)
        if not scene.objects:
            missing.append("objects")
            return False, missing

        # Validate all objects have renderable primitive types
        for obj in scene.objects:
            if not hasattr(obj, 'type') or obj.type is None:
                missing.append("object_primitive_types")
                break

        # Domain-specific validation
        if spec.domain == PhysicsDomain.OPTICS:
            missing.extend(self._validate_optics_scene(scene))
        elif spec.domain == PhysicsDomain.CURRENT_ELECTRICITY:
            missing.extend(self._validate_circuit_scene(scene))
        elif spec.domain == PhysicsDomain.MECHANICS:
            missing.extend(self._validate_mechanics_scene(scene))

        return len(missing) == 0, missing

    def _validate_optics_scene(self, scene: Scene) -> List[str]:
        """Validate the completeness of an optics scene."""
        missing = []
        has_lens_or_mirror = any(obj.type in [PrimitiveType.LENS, PrimitiveType.MIRROR] for obj in scene.objects)
        has_object = any(obj.properties.get('is_object') for obj in scene.objects)
        has_image = any(obj.properties.get('is_image') for obj in scene.objects)

        if not has_lens_or_mirror:
            missing.append("lens_or_mirror")
        if not has_object:
            missing.append("object")
        if not has_image:
            missing.append("image")
        return missing

    def _validate_circuit_scene(self, scene: Scene) -> List[str]:
        """Validate the completeness of a circuit scene."""
        missing = []
        has_power_source = any(obj.type == PrimitiveType.BATTERY_SYMBOL for obj in scene.objects)
        has_component = any(obj.type in [PrimitiveType.RESISTOR_SYMBOL, PrimitiveType.CAPACITOR_SYMBOL] for obj in scene.objects)

        if not has_power_source:
            missing.append("power_source")
        if not has_component:
            missing.append("circuit_component")
        return missing

    def _validate_mechanics_scene(self, scene: Scene) -> List[str]:
        """Validate the completeness of a mechanics scene."""
        missing = []
        has_mass = any(obj.type == PrimitiveType.MASS for obj in scene.objects)
        if not has_mass:
            missing.append("mass")
        return missing


class GenericInterpreter:
    """Generic interpreter for domains without specific interpreters"""

    def __init__(self, domain: str):
        self.domain = domain

    def interpret(self, spec: Dict) -> Scene:
        """Convert spec dict to scene using generic approach"""

        scene = Scene()
        scene.metadata["domain"] = self.domain

        # Convert objects from spec to scene objects
        for obj in spec.get('objects', []) or []:
            obj_type = self._map_object_type(obj.get('type', 'unknown'))

            scene.objects.append(SceneObject(
                id=obj.get('id', f"obj_{len(scene.objects)}"),
                type=obj_type,
                properties=obj.get('properties', {})
            ))

        # Convert constraints from spec
        for constraint in spec.get('constraints', []) or []:
            constraint_type = self._map_constraint_type(constraint.get('type', 'unknown'))

            if constraint_type:
                scene.constraints.append(Constraint(
                    type=constraint_type,
                    objects=constraint.get('objects', []),
                    value=constraint.get('value')
                ))

        return scene

    def _map_object_type(self, type_str: str) -> PrimitiveType:
        """Map object type string to PrimitiveType"""

        mapping = {
            # General
            'rectangle': PrimitiveType.RECTANGLE,
            'circle': PrimitiveType.CIRCLE,
            'line': PrimitiveType.LINE,
            'arrow': PrimitiveType.ARROW,
            'point': PrimitiveType.POINT,
            'polyline': PrimitiveType.POLYLINE,

            # Mechanics
            'mass': PrimitiveType.MASS,
            'block': PrimitiveType.MASS,
            'pulley': PrimitiveType.PULLEY,
            'spring': PrimitiveType.SPRING,
            'force': PrimitiveType.ARROW,

            # Electrostatics & Circuits
            'charge': PrimitiveType.CHARGE,
            'capacitor': PrimitiveType.CAPACITOR_SYMBOL,
            'resistor': PrimitiveType.RESISTOR_SYMBOL,
            'battery': PrimitiveType.BATTERY_SYMBOL,
            'field_line': PrimitiveType.FIELD_LINE,

            # Optics
            'lens': PrimitiveType.LENS,
            'mirror': PrimitiveType.MIRROR,
            'principal_axis': PrimitiveType.LINE,
            'focal_point': PrimitiveType.FOCAL_POINT,
            'ray': PrimitiveType.POLYLINE,
        }

        return mapping.get(type_str.lower(), PrimitiveType.RECTANGLE)

    def _map_constraint_type(self, type_str: str) -> Optional[ConstraintType]:
        """Map constraint type string to ConstraintType"""

        mapping = {
            'geometric': ConstraintType.COINCIDENT,
            'connected': ConstraintType.CONNECTED,
            'connected_to': ConstraintType.CONNECTED,
            'series': ConstraintType.SERIES,
            'parallel': ConstraintType.PARALLEL,
            'collinear': ConstraintType.COLLINEAR,
            'symmetric': ConstraintType.SYMMETRIC,
            'perpendicular': ConstraintType.PERPENDICULAR,
            'distance': ConstraintType.DISTANCE,
            'aligned_h': ConstraintType.ALIGNED_H,
            'aligned_v': ConstraintType.ALIGNED_V,
            'centered': ConstraintType.CENTERED,
        }

        return mapping.get(type_str.lower())


    def _add_focal_points(self, scene: Scene, spec: CanonicalProblemSpec) -> Scene:
        """Add focal points for lenses and mirrors in optics problems."""
        for obj in scene.objects:
            if obj.type in [PrimitiveType.LENS, PrimitiveType.MIRROR]:
                focal_length = obj.properties.get('focal_length')
                if focal_length:
                    # Add two focal points, one on each side of the lens/mirror
                    scene.objects.append(SceneObject(
                        id=f"{obj.id}_f1",
                        type=PrimitiveType.FOCAL_POINT,
                        properties={
                            'parent': obj.id,
                            'distance': -focal_length,
                            'side': 'left'
                        }
                    ))
                    scene.objects.append(SceneObject(
                        id=f"{obj.id}_f2",
                        type=PrimitiveType.FOCAL_POINT,
                        properties={
                            'parent': obj.id,
                            'distance': focal_length,
                            'side': 'right'
                        }
                    ))
        return scene

    def _validate_optics_scene(self, scene: Scene) -> List[str]:
        """Validate the completeness of an optics scene."""
        missing = []
        has_lens_or_mirror = any(obj.type in [PrimitiveType.LENS, PrimitiveType.MIRROR] for obj in scene.objects)
        has_object = any(obj.properties.get('is_object') for obj in scene.objects)
        has_image = any(obj.properties.get('is_image') for obj in scene.objects)

        if not has_lens_or_mirror:
            missing.append("lens_or_mirror")
        if not has_object:
            missing.append("object")
        if not has_image:
            missing.append("image")
        return missing

    def _validate_circuit_scene(self, scene: Scene) -> List[str]:
        """Validate the completeness of a circuit scene."""
        missing = []
        has_power_source = any(obj.type == PrimitiveType.BATTERY_SYMBOL for obj in scene.objects)
        has_component = any(obj.type in [PrimitiveType.RESISTOR_SYMBOL, PrimitiveType.CAPACITOR_SYMBOL] for obj in scene.objects)

        if not has_power_source:
            missing.append("power_source")
        if not has_component:
            missing.append("circuit_component")
        return missing

    def _validate_circuit_scene(self, scene: Scene) -> List[str]:
        """Validate the completeness of a circuit scene."""
        missing = []
        has_power_source = any(obj.type == PrimitiveType.BATTERY_SYMBOL for obj in scene.objects)
        has_component = any(obj.type in [PrimitiveType.RESISTOR_SYMBOL, PrimitiveType.CAPACITOR_SYMBOL] for obj in scene.objects)

        if not has_power_source:
            missing.append("power_source")
        if not has_component:
            missing.append("circuit_component")
        return missing

    def _validate_mechanics_scene(self, scene: Scene) -> List[str]:
        """Validate the completeness of a mechanics scene."""
        missing = []
        has_mass = any(obj.type == PrimitiveType.MASS for obj in scene.objects)
        if not has_mass:
            missing.append("mass")
        return missing